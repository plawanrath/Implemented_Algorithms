import java.text.DecimalFormat;
import java.util.*;

public class MDS {

    TreeMap<Long, Item> itemCollection = new TreeMap<>();

    int insert(long id, double price, long[] description, int size) {
        if(itemCollection.containsKey(id))
        {
            Item value = itemCollection.get(id);
            if(!ifArrayIsEmpty(description))
            {
                value.description = description;
                value.price = price;
            }
            else
            {
                value.price = price;
            }
            return 0;
        }
        else
        {
            itemCollection.put(id, new Item(id, price, description, size));
            return 1;
        }
    }

    double find(long id) {
        Item value = itemCollection.get(id);
        if(value != null)
            return value.price;
        return 0;
    }

    long delete(long id) {
        Item value = itemCollection.remove(id);
        if(value != null)
        {
            long sum = 0;
            for(long val : value.description)
                sum += val;
            return sum;
        }
        return 0;
    }

    double findMinPrice(long des) {
        ArrayList<Double> res = getPricesMatchingDescriptions(des);
        return res.size() > 0 ? res.get(0) : 0;
    }

    double findMaxPrice(long des) {
        ArrayList<Double> res = getPricesMatchingDescriptions(des);
        Collections.sort(res,Collections.reverseOrder());
        return res.size() > 0 ? res.get(0) : 0;
    }

    int findPriceRange(long des, double lowPrice, double highPrice) {
        return findPricesInRangeGivenDescription(des, lowPrice, highPrice).size();
    }

    double priceHike(long minid, long maxid, double rate) {
        double sum = 0;
        for(Map.Entry<Long,Item> entry : itemCollection.entrySet())
        {
            long key = entry.getKey();
            Item value = entry.getValue();
            if(key >= minid && key <= maxid)
            {
                double hikedPrice = value.price + ((value.price)*(rate/100));
                int intermediateInt = (int) (hikedPrice * 100);
                DecimalFormat df = new DecimalFormat("#.##");
                hikedPrice = ((double)intermediateInt/100);
                sum += Double.parseDouble(df.format(hikedPrice  - value.price));
                value.price = hikedPrice;
                itemCollection.put(key, value);
            }
        }
        return sum;
    }

    int range(double lowPrice, double highPrice) {
        int count = 0;
        for(Map.Entry<Long,Item> entry : itemCollection.entrySet())
        {
            Item value = entry.getValue();
            if(value.price >= lowPrice && value.price <= highPrice)
                count++;
        }
        return count;
    }

    int samesame() {
        ArrayList<Item> sortedMap = getMapSortedOnNumberOfDescriptions();
        int count = 0;
        Comparator<Item> cObj2 = (o1, o2) -> {
            if(Arrays.equals(o1.description,o2.description)) {
                o1.equalDescription = true;
                o2.equalDescription = true;
                return 1;
            }
            else {
                return -1;
            }
        };
        Collections.sort(sortedMap, cObj2);
        for(Item value : sortedMap)
        {
            if(value.equalDescription && value.description.length >= 8)
                count++;
        }
        return count;
    }

    private ArrayList<Double> getPricesMatchingDescriptions(long desc)
    {
        ArrayList<Double> res = new ArrayList<>();
        for(Map.Entry<Long,Item> entry : itemCollection.entrySet())
        {
            Item value = entry.getValue();
            if(value.search(desc))
                res.add(value.price);
        }
        Collections.sort(res);
        return res;
    }

    private ArrayList<Double> filterPricesOnRange(List<Double> array, double low, double high)
    {
        ArrayList<Double> res = new ArrayList<>();
        for(double val : array)
        {
            if(val >= low && val < high)
                res.add(val);
        }
        return res;
    }

    private ArrayList<Double> findPricesInRangeGivenDescription(long desc, double low, double high)
    {
        return filterPricesOnRange(getPricesMatchingDescriptions(desc), low, high);
    }

    private ArrayList<Item> getMapSortedOnNumberOfDescriptions()
    {
        Comparator<Item> cObj = (o1, o2) -> new Integer(getNoOfElementsInDescription(o1.description)).compareTo(new Integer(getNoOfElementsInDescription(o2.description)));
        ArrayList<Item> val = new ArrayList<>();
        for(Map.Entry<Long, Item> entry :itemCollection.entrySet())
                val.add(entry.getValue());
        Collections.sort(val,cObj);
        return val;
    }
    private boolean ifArrayIsEmpty(long[] description)
    {
        for(int i=0;i<description.length;i++)
            if(description[i] != 0)
                return false;
        return true;
    }

    private int getNoOfElementsInDescription(long[] description)
    {
        int count = 0;
        for(int i=0;i<description.length;i++)
        {
            if(description[i] != 0)
                count++;
            else
                break;
        }
        return count;
    }

}