// Ver 1.0:  Wec, Feb 3.  Initial description.

public interface Index {
    public void putIndex(int index);
    public int getIndex();
}

